
public class OddEven
{
	public static void main(String[] args) {
	    int num1=Integer.parseInt(args[0]);
	    if (num1%2==0){
	        System.out.println("Even");
	        }else{
	            System.out.println("Odd");
	        }

	}
}

