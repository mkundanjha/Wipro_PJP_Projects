public class VideoStore{
    Video[] videos = new Video[200];
    static int index = 0;
    
    public void addVideo(String name){
       videos[index] = new Video(name);
       index++;
       System.out.println("Video \""+name+"\" added successfully.");       
   } 

    public void doCheckout(String name){
       for(int i=0;i<videos.length;i++){
            if (videos[i] != null && videos[i].getName().equals(name)) {
               videos[i].doCheckout();
               break;
           }
        }
       System.out.println("Video \""+name+"\" checked out successfully.");     
   }

   public void doReturn(String name){
        for(int i=0;i<videos.length;i++){
            if (videos[i] != null && videos[i].getName().equals(name)){
               videos[i].doReturn();
               break;
           }
        }
        System.out.println("Video \""+name+"\" reterned successfully.");     
    }
    
   public void receiveRating(String name,int rating){
       for(int i=0;i<videos.length;i++){
            if (videos[i] != null && videos[i].getName().equals(name)){
                videos[i].receiveRating(rating);
                break;
            }
       }
       System.out.println("Rating \""+rating+" - has been mapped to the Video\""+name+"\"");    
   }
   
   public void listInventory(){
       System.out.println("------------------------------------------------------------------");
       System.out.println("Video Name        |       Checkout Status        |       Rating");
       System.out.println("------------------------------------------------------------------");
       
       for(int i=0;i<videos.length;i++){
           if(videos[i] != null) {
            System.out.println(videos[i].getName()+"       |      "+videos[i].getCheckout()+"        |       "+videos[i].getRating());
           }
       }
   }
    
}
