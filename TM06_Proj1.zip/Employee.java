public class Employee{
    String name;
    int id;
    int age;
    double salary;
    Employee(int id,String name,int age,double salary){
        this.id=id;
        this.name=name;
        this.age=age;
        this.salary=salary;
    }
    
    public String getName(){
        return name;
    }
    public int getID(){
        return id;
    }
    public int getAge(){
        return age;
    }
    public double getSalary(){
        return salary;
    }
}

