import java.util.Scanner;

public class EmployeeLauncher{
    public static void main (String[] args) {
        String name;
        int id;
        int age;
        double salary;
        int input;
        int flag=0;
        
        EmployeeList employee= new EmployeeList();
        
        
        Scanner scanner=new Scanner(System.in);
        
        while(flag!=0){
            System.out.println("\nMAIN MENU\n");
            System.out.println("1. Add an Employee \n2.Dispaly All \n3.Exit\n");
            input=Integer.parseInt(scanner.nextLine());
            flag=input;
            
            switch(input){
		        case 1:{
					System.out.print("\nEnter Employee ID: ");
					id=Integer.parseInt(scanner.nextLine());
		            System.out.print("\nEnter Employee Name: ");
		            name=scanner.nextLine();
		            System.out.print("\nEnter Employee Age: ");
		            age=Integer.parseInt(scanner.nextLine());
		            System.out.print("\nEnter Employee salary: ");
		            salary=Double.parseDouble(scanner.nextLine());
		            employee.addEmployee(id,name,age,salary);
		            break;
		        }
		        case 2:{
		            employee.displayEmployee();
		            break;
		            
		        }
		   
		     }
		     scanner.close();
    }
}}
