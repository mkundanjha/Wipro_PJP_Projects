public class EmployeeList{
    Employee[] employee=new Employee[100];
    static int index=0;
    
    public void addEmployee(int id,String name,int age,double salary ){
        employee[index]=new Employee(id,name,age,salary);
        index++;
        }
    
    public void displayEmployee(){
        System.out.println("------Report-------");
        for (int i=0;i<employee.length;i++){
            if(employee[i]!=null){
                System.out.println(employee[i].getID()+" "+employee[i].getName()+" "+employee[i].getAge()+" "+employee[i].getSalary());
            }
        System.out.println("-------End of Report--------");
        }
    }
}
