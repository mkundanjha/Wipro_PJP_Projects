import java.util.Scanner;

abstract class Account{
    double intrestRate;
    double amount;

    abstract double calculaeteIntrest();
    
}

class FDAccount extends Account{
    double intrest;
    double amount;
    int noOfDays;
    int ageOfACHolder;
    
    FDAccount(double amount,int noOfDays,int ageOfACHolder){
        this.amount=amount;
        this.noOfDays=noOfDays;
        this.ageOfACHolder=ageOfACHolder;
        
    }
    
    public double calculaeteIntrest(){
        if (amount<10000000){
            if (ageOfACHolder<65){
                if(noOfDays>=7 && noOfDays<=14)
                    intrest= (4.5*amount);
                if(noOfDays>=15 && noOfDays<=29)
                    intrest= (4.75*amount);
                if(noOfDays>=30 && noOfDays<=45)
                    intrest= (5.50*amount);
                if(noOfDays>45 && noOfDays<=60)
                    intrest= (7*amount);
                if(noOfDays>=61 && noOfDays<=184)
                    intrest= (7.50*amount);
                if(noOfDays>=185 && noOfDays<=365)
                    intrest= (8.00*amount);
            }
            else{
                if(noOfDays>=7 && noOfDays<=14)
                    intrest= (5.0*amount);
                    
                if(noOfDays>=15 && noOfDays<=29)
                    intrest= (5.25*amount);
                    
                if(noOfDays>=30 && noOfDays<=45)
                    intrest= (6.00*amount);
                    
                if(noOfDays>45 && noOfDays<=60)
                    intrest= (7.50*amount);
                    
                if(noOfDays>=61 && noOfDays<=184)
                    intrest= (8.00*amount);
                    
                if(noOfDays>=185 && noOfDays<=365)
                    intrest= (8.50*amount);
                }
            
        }else{
                if(noOfDays>=7 && noOfDays<=14)
                    intrest= (6.50*amount);
                    
                if(noOfDays>=15 && noOfDays<=29)
                    intrest= (6.75*amount);
                    
                if(noOfDays>=30 && noOfDays<=45)
                    intrest= (6.75*amount);
                    
                if(noOfDays>45 && noOfDays<=60)
                    intrest= (8*amount);
                    
                if(noOfDays>=61 && noOfDays<=184)
                    intrest= (8.50*amount);
                    
                if(noOfDays>=185 && noOfDays<=365)
                    intrest= (10.00*amount);
        }
        return (intrest/100);
    }
    
}

class SBAccount extends Account{
    double intrest;
    double amount;
       
    SBAccount(double amount){
        this.amount=amount;
    }
    
    public double calculaeteIntrest(){
        intrest= (4*amount);
        return (intrest/100);
        
    }
    
}
    
class RDAccount extends Account{
    double intrest;
    double amount;
    int noOfMonths;
    int ageOfACHolder;
    double monthlyAmount;

    
    RDAccount(double amount,int noOfMonths,int ageOfACHolder){
        this.amount=amount;
        this.noOfMonths=noOfMonths;
        this.ageOfACHolder=ageOfACHolder;
    }
    
    public double calculaeteIntrest(){
            if (ageOfACHolder<65){
                if(noOfMonths<=6)
                    intrest= (7.50*amount);
                    
                if(noOfMonths>6 && noOfMonths<=9)
                    intrest= (7.75*amount);
                    
                if(noOfMonths>9 && noOfMonths<=12)
                    intrest= (8.00*amount);
                    
                if(noOfMonths>12 && noOfMonths<=15)
                    intrest= (8.25*amount);
                    
                if(noOfMonths>15 && noOfMonths<=18)
                    intrest= (8.50*amount);
                    
                if(noOfMonths>18 && noOfMonths<=21)
                    intrest= (8.75*amount);
                
            
            }
            else{
                if(noOfMonths<=6)
                    intrest= (8.00*amount);
                    
                if(noOfMonths>6 && noOfMonths<=9)
                    intrest= (8.25*amount);
                    
                if(noOfMonths>9 && noOfMonths<=12)
                    intrest= (8.50*amount);
                    
                if(noOfMonths>12 && noOfMonths<=15)
                    intrest= (8.75*amount);
                    
                if(noOfMonths>15 && noOfMonths<=18)
                    intrest= (9.00*amount);
                    
                if(noOfMonths>18 && noOfMonths<=21)
                    intrest= (9.25*amount);
                }
        return (intrest/100);
        }
    
}

public class Main{

    public static void main (String[] args) {
        FDAccount fd;
        SBAccount sb;
        RDAccount rd;
        double amount;
        int noOfDays;
        int noOfMonths;
        int age;
        
        int monthlyAmount;
        int flag=0;
        Scanner scanner =new Scanner(System.in);
        

        
        
     
    while(flag!=4){
		System.out.println("\nMAIN MENU \n---------\n");
		System.out.println("1.Intrest Calculator - SB \n2.Intrest Calculator - FD \n3.Intrest Calculator - RD \n4.Exit \n");
		System.out.print("Enter your option (1..4): ");
		String input= scanner.nextLine();
		int number=Integer.parseInt(input);
		flag=number;
		    
		    switch(number){
		        case 1:{
		            System.out.print("\nEnter your average amount in your account: ");
		            amount=Double.parseDouble(scanner.nextLine());
		            if (amount<0){
                        System.out.println("\nInvalid Amount. Please enter non-negative values.");
                        break;
                    }
		            sb=new SBAccount(amount);
		            System.out.println("\nIntrest Gained: Rs. "+sb.calculaeteIntrest());
		            break;
		        }
		        case 2:{
		            System.out.print("\nEnter your FD amount: ");
		            amount=Double.parseDouble(scanner.nextLine());
		            System.out.print("\nEnter the number of days: ");
		            noOfDays=Integer.parseInt(scanner.nextLine());
		            System.out.print("\nEnter your age: ");
		            age=Integer.parseInt(scanner.nextLine());
		            if (amount<0){
                        System.out.println("\nInvalid Amount. Please enter non-negative values.");
                        break;
                    }
                    if (noOfDays<0){
                        System.out.println("\nInvalid number of days. Please enter non-negative values.");
                        break;
                    }
                    if (age<0){
                        System.out.println("\nInvalid number of age. Please enter non-negative values.");
                        break;
                    }
		            fd=new  FDAccount(amount,noOfDays,age);
		            
		            System.out.println("\nIntrest Gained: Rs. "+fd.calculaeteIntrest());
		            break;
		            
		        }
		        case 3:{
		            System.out.print("\nEnter your RD amount: ");
		            amount=Double.parseDouble(scanner.nextLine());
		            System.out.print("\nEnter the number of months: ");
		            noOfMonths=Integer.parseInt(scanner.nextLine());
		            System.out.print("\nEnter your age: ");
		            age=Integer.parseInt(scanner.nextLine());
		            if (amount<0){
                        System.out.println("\nInvalid Amount. Please enter non-negative values.");
                        break;
                    }
                    if (noOfMonths<0){
                        System.out.println("\nInvalid number of months. Please enter non-negative values.");
                        break;
                    }
                    if (age<0){
                        System.out.println("\nInvalid number of age. Please enter non-negative values.");
                        break;
                    }
		            rd=new RDAccount(amount,noOfMonths,age);
		            System.out.println("\nIntrest Gained: Rs. "+rd.calculaeteIntrest());
		            break;
		            
		        }
		    }
    }
    }
}
		           











